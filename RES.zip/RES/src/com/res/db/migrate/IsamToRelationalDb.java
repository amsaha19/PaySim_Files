package com.res.db.migrate;

public class IsamToRelationalDb {

}
