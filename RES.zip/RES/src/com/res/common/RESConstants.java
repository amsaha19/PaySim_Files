package com.res.common;

public class RESConstants {

	public static final String INSTANCE_NAME="instance_";
	
}
