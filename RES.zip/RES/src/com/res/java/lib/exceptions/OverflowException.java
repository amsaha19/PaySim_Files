package com.res.java.lib.exceptions;

public class OverflowException extends ArithmeticException {

	public OverflowException(String msg) {
		super(msg);
	}
	private static final long serialVersionUID = 1L;

}
