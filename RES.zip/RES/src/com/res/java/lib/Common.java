package com.res.java.lib;

public class Common {

}
