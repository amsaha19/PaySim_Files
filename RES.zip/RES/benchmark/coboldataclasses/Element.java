/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package coboldataclasses;

    public class Element {
        long element1;
        long element2;
        String element3;
        public Element() {
            element1=0;
            element2=0;
            element3="";
        }
    }